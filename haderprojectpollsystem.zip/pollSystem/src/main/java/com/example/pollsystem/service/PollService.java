package com.example.pollsystem.service;

import com.example.pollsystem.model.Poll;
import com.example.pollsystem.repository.PollRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class PollService {

    private final PollRepository pollRepository;

    public PollService(PollRepository pollRepository) {
        this.pollRepository = pollRepository;
    }

    public List<Poll> getAllPolls() {
        return pollRepository.findAll();
    }

    public Optional<Poll> getPollById(Long id) {
        return pollRepository.findById(id);
    }

    public Poll createPoll(Poll poll) {
        return pollRepository.save(poll);
    }

    @Transactional
    public Optional<Poll> updatePoll(Long id, Poll updatedPoll) {
        return pollRepository.findById(id).map(poll -> {
            poll.setQuestion(updatedPoll.getQuestion());
            poll.setOptionA(updatedPoll.getOptionA());
            poll.setOptionB(updatedPoll.getOptionB());
            poll.setOptionC(updatedPoll.getOptionC());
            poll.setOptionD(updatedPoll.getOptionD());
            return pollRepository.save(poll);
        });
    }

    @Transactional
    public void deletePoll(Long id) {
        pollRepository.deleteById(id);
    }

    public List<Map<String, Object>> getAllQuestionsWithAnswerCounts() {
        List<Poll> polls = pollRepository.findAll();
        List<Map<String, Object>> results = new ArrayList<>();
        for (Poll poll : polls) {
            Map<String, Object> questionData = new HashMap<>();
            questionData.put("questionId", poll.getId());
            questionData.put("question", poll.getQuestion());
            questionData.put("counts", null); // Reuse method in AnswerService for counts
            results.add(questionData);
        }
        return results;
    }
}
