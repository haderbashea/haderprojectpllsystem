package com.example.pollsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PollSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(PollSystemApplication.class, args);
    }
}
