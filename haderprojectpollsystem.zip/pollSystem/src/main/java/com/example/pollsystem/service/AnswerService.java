package com.example.pollsystem.service;

import com.example.pollsystem.dto.AnswerDTO;
import com.example.pollsystem.model.Answer;
import com.example.pollsystem.model.Poll;
import com.example.pollsystem.repository.AnswerRepository;
import com.example.pollsystem.repository.PollRepository;
import com.example.pollsystem.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnswerService {

    private final AnswerRepository answerRepository;
    private final UserRepository userRepository;
    private final PollRepository pollRepository;

    public AnswerService(AnswerRepository answerRepository, UserRepository userRepository, PollRepository pollRepository) {
        this.answerRepository = answerRepository;
        this.userRepository = userRepository;
        this.pollRepository = pollRepository;
    }

    public Answer saveAnswer(Answer answer) {
        Poll poll = pollRepository.findById(answer.getPoll().getId())
                .orElseThrow(() -> new IllegalArgumentException("Poll does not exist"));

        // Validate selected option
        if (!poll.getOptionA().equalsIgnoreCase(answer.getSelectedOption()) &&
                !poll.getOptionB().equalsIgnoreCase(answer.getSelectedOption()) &&
                !poll.getOptionC().equalsIgnoreCase(answer.getSelectedOption()) &&
                !poll.getOptionD().equalsIgnoreCase(answer.getSelectedOption())) {
            throw new IllegalArgumentException("Invalid answer option");
        }

        return answerRepository.save(answer);
    }

    public List<AnswerDTO> getAnswersByUserId(Long userId) {
        return answerRepository.findByUserId(userId).stream()
                .map(answer -> new AnswerDTO(
                        answer.getId(),
                        answer.getUser().getId(),
                        answer.getPoll().getId(),
                        answer.getSelectedOption()))
                .collect(Collectors.toList());
    }

    public Long getTotalQuestionsAnsweredByUser(Long userId) {
        return answerRepository.countByUserId(userId);
    }

    public Map<String, Long> getCountByPollId(Long pollId) {
        List<Object[]> results = answerRepository.countAnswersByPollId(pollId);
        Map<String, Long> counts = new HashMap<>();
        for (Object[] result : results) {
            counts.put((String) result[0], (Long) result[1]);
        }
        return counts;
    }

    public Long getTotalAnswersByPollId(Long pollId) {
        return answerRepository.countByPollId(pollId);
    }
}
